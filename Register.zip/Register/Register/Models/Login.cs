﻿using System;
namespace Register.Models
{
    public class Login
    {
        public String Email { get; set; }
        public String Pwd { get; set; }
    }
}
